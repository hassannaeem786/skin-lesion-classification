
# Skin Lesion Classification using CNN

## Project Overview
This project uses a Convolutional Neural Network (CNN)
to classify skin lesion images into seven categories
using the HAM10000 dataset.

## Dataset
HAM10000 - Human Against Machine with 10000 training images.

## Classes
- akiec
- bcc
- bkl
- df
- mel
- nv
- vasc

## Model
- CNN architecture
- Input image size: 224x224
- Optimizer: Adam
- Loss: Sparse Categorical Crossentropy

## Dataset Split
- Training: 7991 images
- Validation: 1025 images
- Testing: 999 images

## Final Test Results
- Test Accuracy: 65.87%
- Test Loss: 1.2015

## Files
- skin_lesion_model.keras
- class_names.json

## Disclaimer
This is an educational university project.
It is not intended for medical diagnosis.
